<?php
//Shit i made that makes the site cleaner and easier to set up - Flarf
define("SITENAME","Project Vapor");
define("CURRENCYNAME","Diamond/'s");
define("SITEDOMAIN","https://projvap.cf");
define("SMALLLOGOPATH","https://projvap.cf/img/logosmall.png");
define("FULLLOGOPATH","https://projvap.cf/img/logo.png?v1");
define("YOUTUBETRAILERLINK","https://www.youtube-nocookie.com/embed/Mvf9JCG2KaE");
?>